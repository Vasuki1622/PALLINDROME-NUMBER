import java.util.*;
public class Main {
public static void main(String[] args) {
    
 int r,sum=0,temp;
 int n=545;
temp=n;
while(n>0) {
     r = n % 10;
      sum =(sum * 10) + r;
      n /= 10;
    }

  
    if(temp==sum){
        System.out.println("PALINDROM");
    }
    else{
         System.out.println(" NOT A PALINDROM");
    }
}
}